Author: BlueLife , Velociraptor
www.sordum.org

########### -- PowerRun v1.1 -- ###########
( September 08, 2016)

Changelog:

1. [ Fixed ] - PowerRun Can't delete some registry files which belong to TrustedInstaller
2. [Added] - GUI
3. [Added] - Drag and drop support
4. [Added] - Run with Parameter , Startup Windows state features
5. [Added] - Jump the registry key feature 
6. [Added] - Create a vbs or Bat file feature 
7. [Added] - Cmd support Updated
8. [Added] - Language support

-------------------------------------------------------

########### -- PowerRun v1.0 -- ###########
( August 08, 2016)

PowerRun is a one click portabel freeware tool to launch regedit.exe or Cmd.exe 
with the same privileges as the TrustedInstaller it has No GUI